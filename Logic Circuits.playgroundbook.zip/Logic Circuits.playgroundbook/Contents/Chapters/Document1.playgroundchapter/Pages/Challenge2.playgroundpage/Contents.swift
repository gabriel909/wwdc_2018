/*:
![Logic Circuits Builder](page2_text.png)
 
 */
