let _ = startScene() //Função definida em "Sources/Starter.swift" desta page
