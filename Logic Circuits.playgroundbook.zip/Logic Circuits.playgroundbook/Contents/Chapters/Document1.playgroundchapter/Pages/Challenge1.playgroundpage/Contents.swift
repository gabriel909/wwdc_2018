/*:
 ![Boolean Algebra](page1_text.png)
*/
